function [E,A,D,B,R,Loss,ObjError_cell] = DMBU(Y,varargin)
% [E,A,D,B,Error] = DMBU(Y,'NUM_ENDMS',m,'MAX_ITERATIONS',maxiteration,'INITIALIZATION',style,'PLOT_ERROR','yes','SHOW_ERROR', 'yes');
% DMBU
% for Nonlinear Hyperspectral.
% input-------------------------------------------------------------------- 
% Y is hyperspectral Data(bands*pixels);
% varargin;
% m is the number of endmembers;
% maxiteration is the number of max-iteration;
% style is the alternative way of initialization: vca (1) or nfindr (2);
% 'yes' or 'no' denote whether or not plot reconstructe error.
% output-------------------------------------------------------------------
% E and A are endmembers and abundance;
% D and B are bilinear effects;
% yes: show value or figure. The opposite is set as 'no'.
% The function was written by Yuanchao. 
% Jun.2019
%% Start
currentFolder = pwd;
addpath(genpath(currentFolder))
plot_RE = 'no';
show_RE = 'no';
if (nargin-length(varargin)) ~= 1
    error('Wrong number of required parameters');
elseif (rem(length(varargin),2)==1)
    error('Optional input parameters should always go by pairs');
else
for i = 1:2:(length(varargin)-1)
   switch upper(varargin{i})
          case 'NUM_ENDMS'
                m = varargin{i+1};% m is the number of endmembers
          case 'MAX_ITERATIONS'
                maxiteration = varargin{i+1};% maxiterations is the maximum iteration.
          case 'INITIALIZATION'
                style = varargin{i+1};% Initialization of endmembers
          case 'PLOT_ERROR'
                plot_RE = varargin{i+1};%display
          case 'SHOW_ERROR'
                show_RE = varargin{i+1};%display
          otherwise
                error(['Unrecognized option: ''' varargin{i} '''']);
   end
end
%% Initialization of the linear part
[bands,pixels] = size(Y);
switch style
    case 1
        v = 'off';
        [E, ~, ~] = vca(Y,'Endmembers',m,'verbose',v);
    case 2
        [numBands,Newpixels]=size(Y);
        img = reshape(Y.', 1, Newpixels, numBands); 
        [E,~] = NFINDR(img,m);
end
A = zeros(m,pixels); % Define the size of abundances A.
E1 = ones(bands+1,m);
E1(1:bands,:) = E;
Mixed_1 = ones(bands+1,pixels);
Mixed_1(1:bands,:) = Y;
for i = 1:pixels
    A(:,i) = lsqnonneg(E1,Mixed_1(:,i)); %Initialization var FCLS.
end
%% Initialization of the bilinear part
% Second-reflection effects of endmembers D, abundances B.
% Define the size of matirces
D = zeros(bands,m*(m-1)/2);
B = zeros(m*(m-1)/2,pixels); 
E(find(E<=0))=1e-9; % avoids nan form zeros and negative values in endmembers.
for j = 1:bands
    E2 = bsxfun(@times,E(j,:),E(j,:)');
    E3 = tril(E2,-1);
    d0 = E3(E3~=0);
    D(j,:) = d0; % Initialization of second-order self-interaction.
end
%% Parameters
[Parameter] = Parameters();
%%  Training
Y_Ap = ones(bands,pixels);
ua = 1;
num_iteration = 0;
for i = 1:maxiteration
    num_iteration = num_iteration +1;
%% Task1
    Y_Est = E*A + D*B;% bilinear model
    F1 = E'*(Y.*Y_Ap) + repmat(sum((E*A).*Y_Est,1),m,1);
    F2 = E'*Y_Est + repmat(sum((E*A).*Y.*Y_Ap,1),m,1); 
    % imposing sum-to-one and non-negative
    A = A.*(F1./F2); 
    A = A./repmat(sum(A,1),m,1);
    A(A<0) = 0; % non-negative   
    rx = sum(E.^2,1);
    co = size(E,2);
    rx2 = sum(Y.^2,1);
    co2 = size(Y,2); 
    er = Y - E*A-D*B;
    % posterior
    ef1 = bands*pixels/2;
    ef2 = sum((sum(er.^2,1)/2))';
    tem = 1/gamrnd(ef1,1./ef2)+Parameter.psi;
	[U,p] = chol(tem);
    if p ~= 0
        error('error');
    end
    sigma = U;   
    P1 = exp(-((ones(co,1)*rx)' + ones(co,1)*rx -2*(E'*E))/(2*sigma^2));
    P2 = exp(-((ones(co2,1)*rx)' + ones(co,1)*rx2 -2*(E'*Y))/(2*sigma^2));
    T1 = E'* E; T2 = E'* Y;
    layer = 0;
    while layer < Parameter.layers     
        layer = layer + 1;
        A = A.* (Parameter.lambda*T2+Parameter.mu*P2)./ ((Parameter.lambda*T1 + Parameter.mu*P1)* A); % trade-off
        Ab{1,layer} = A;
        J1 = Parameter.lambda* (part1(m,Y,E,A)+ sum(sum(Y.*Y))/2)+Parameter.mu*(part2(m,Y,E,A,sigma)+ pixels/2);
        lambda = Parameter.lambda;
        mu = Parameter.mu;
        [GE] = Graph_Laplacian(bands,m,pixels,A,E,Y,rx2,co2,sigma,P1,lambda,mu);% Graph Laplacian
        Vge = reshape(GE,m*bands,1); % translate vector
% optimization: Armijo's rule
        E_1 = max(E - ua * GE,0); 
        Eu = reshape(E_1-E,m*bands,1);
        J2 = Parameter.lambda*(part1(m,Y,E_1,A)+ sum(sum(Y.*Y))/2)+Parameter.mu*(part2(m,Y,E_1,A,sigma)+ pixels/2);  
        dp = 1;kp = 1;
       theta = Parameter.theta;
       eta = Parameter.eta;
       [E_1] = Armijo(J1,J2,GE,lambda,mu,theta,eta,sigma,ua,dp,kp,Vge,Eu,E_1,E,A,Y); 
        E = E_1;
        En{1,layer} = E;
        ObjE_cell(1,layer) = sqrt(sum(sum((Y-E*A).^2))/(bands*pixels));
    end
    [~,ind] = min(ObjE_cell);
    A = Ab{1,ind};
    E = En{1,ind};   
%% Task2
    D2 = D;
    B(:,sum(B)==0) = Parameter.eps;
    X = abs(Y-E*A); % generate bilinear effect
    Y_Eplus = (abs(X'*D2)+X'*D2)/2;
    Y_Eminus = (abs(X'*D2)-X'*D2)/2;
    Eplus = (abs(D2'*D2)+D2'*D2)/2;
    Eminus = (abs(D2'*D2)-D2'*D2)/2;
    B = (B'.*(sqrt((Y_Eplus+B'*Eminus)./(Y_Eminus+B'*Eplus))))'; % bilinear effect part
    for i1 = 1:pixels
        a = A(:,i1);
        b = (triu(a*a')-diag(diag(a*a'))+tril(ones(size(a,1)))*(-1))';
        B(:,i1) = b(b~=-1);
    end
    B = B*Parameter.coeff;% limied
    % impose low-rank for background.
    layer2=0;
    while layer2 < Parameter.layers
        layer2 = layer2+1;
        [Ur3,Sr3,Vr3] = svd(B,'econ'); % singular value decomposition
        Ur3(isnan(Ur3)) = 0;
        Sr3(isnan(Sr3)) = 0;
        Vr3(isnan(Vr3)) = 0;
        sr3 = max(abs(diag(Sr3)) - eps./(abs(diag(Sr3))+eps),0);
        B2 = Ur3*diag(sr3)*Vr3'; 
        B = sign(B2).*max(B2 -  eps./(B2 + eps),0);    
        E(find(E<=0)) = 1e-9;% avoid negtive values and zeros
        for j = 1:bands
            E2 = bsxfun(@times,E(j,:),E(j,:)');
            E3 = tril(E2,-1);
            d0 = E3(E3~=0);
            D2(j,:) = d0;% update
        end
        D2 = abs(D2.*((Y-E*A)*B')./D2*(B*B'));
    end
    ObjError_cell(1,i) = sqrt(sum(sum((Y-E*A-D2*B).^2))/(bands*pixels)); % Training should be convergence, otherwise it doesn't make any sense!
    Loss = ObjError_cell(i);
    if strcmp(show_RE, 'yes')
       fprintf('Iteration = %4i |Max Iterations = %4i| (Error is %4i) \n',num_iteration, maxiteration,Loss)
    else 
       disp(['number of iterations' num2str(num_iteration) '/' num2str(maxiteration)]);% exhibit Iteration
    end
    tolerate = 80;
%% Stop condition 
    if length(ObjError_cell)>tolerate
        Le1=ObjError_cell(num_iteration)-ObjError_cell(num_iteration-1);
        Le2=ObjError_cell(num_iteration)-ObjError_cell(num_iteration-3);
        if Le1<0 && Le2<0
            fprintf('Convergence %d Iteration', num_iteration);
        break
        end
    elseif Loss < 1e-4 || num_iteration == maxiteration % save time
        fprintf('Stop %d Iteration', num_iteration);
    break
    end
    R = D2*B;
end
%% showing
if strcmp(plot_RE, 'yes')
   figure
   hold on
   plot(ObjError_cell,'black','LineWidth',1);
   ylabel('RE','fontsize',15);
   xlabel('Iterations','fontsize',15);
   set(gca,'FontSize',12);
end
end